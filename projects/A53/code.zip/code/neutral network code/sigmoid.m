function g = sigmoid(z)
    g = tanh(z);
end
