function g = sigmoidgrid(z)
   g = 1 - tanh(z).^2;
end
